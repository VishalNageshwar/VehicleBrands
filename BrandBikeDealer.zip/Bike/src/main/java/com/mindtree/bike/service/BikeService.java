package com.mindtree.bike.service;

public interface BikeService {

	void addBike(int brandId, String bikeName, float bikePrice);

}
