package com.mindtree.bike.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bike.entity.Bike;
import com.mindtree.bike.entity.Brand;
import com.mindtree.bike.repository.BikeRepository;
import com.mindtree.bike.repository.BrandRepository;
import com.mindtree.bike.service.BikeService;
@Service
public class BikeServiceImpl implements BikeService
{
	@Autowired
	BikeRepository bikerepo;
	@Autowired
	BrandRepository brandrepo;

	@Override
	public void addBike(int brandId, String bikeName, float bikePrice) 
	{
		Brand brand=brandrepo.findById(brandId).get();
		Bike bike=new Bike();
		bike.setBikeName(bikeName);
		bike.setBikePrice(bikePrice);
		bike.setBrand(brand);
		bikerepo.save(bike);
		
		
	}

}
