package com.mindtree.bike.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.mindtree.bike.entity.Bike;
import com.mindtree.bike.entity.Brand;
import com.mindtree.bike.entity.Dealer;
import com.mindtree.bike.repository.BrandRepository;
import com.mindtree.bike.repository.DealerRepository;
import com.mindtree.bike.service.DealerService;
@Service
public class DealerServiceImpl implements DealerService
{
	@Autowired
	DealerRepository dealerrepo;
   @Autowired
   BrandRepository brandrepo;
	@Override
	public List<Dealer> getDealer() 
	{
		List<Dealer>dealers=dealerrepo.findAll();
		return dealers;
		
	}

	@Override
	public void assignDealer(int brandId, int dealerId) 
	{
		Brand brand=brandrepo.findById(brandId).get();
		Dealer dealer=dealerrepo.findById(dealerId).get();
		dealer.setBrand(brand);
		dealerrepo.save(dealer);
		
		
		
	}

	@Override
	public List<Bike> getBikeByDealerName(String dealerName) 
	{
		Dealer dealer=dealerrepo.findBydealerName(dealerName);
		Brand brand=dealer.getBrand();
		List<Bike>bikes=brand.getBikes();
		return bikes;
	}

}
