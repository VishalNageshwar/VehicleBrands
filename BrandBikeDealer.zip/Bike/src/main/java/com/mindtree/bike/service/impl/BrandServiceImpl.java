package com.mindtree.bike.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bike.entity.Bike;
import com.mindtree.bike.entity.Brand;
import com.mindtree.bike.repository.BrandRepository;
import com.mindtree.bike.service.BrandService;
@Service
public class BrandServiceImpl implements BrandService
{
	@Autowired
	BrandRepository brandrepo;

	@Override
	public List<Brand> getBrand() 
	{
	      List<Brand>brands=brandrepo.findAll();
	      
	       
		return brands;
	}

	@Override
	public Float getTotalInvest(int brandId) 
	{
		Brand brand=brandrepo.findById(brandId).get();

		float sum=0;
		  
	List<Bike>bikes=brand.getBikes();
	 for (Bike bike : bikes) 
	 {
		sum=sum+bike.getBikePrice();
	}
	 return sum;
		
		
	}

	@Override
	public Brand getAllBrand(int brandId) 
	{
		Brand brand=brandrepo.findById(brandId).get();
		return brand;
	}

}
