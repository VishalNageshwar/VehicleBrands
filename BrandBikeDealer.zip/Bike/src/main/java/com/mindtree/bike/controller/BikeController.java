package com.mindtree.bike.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.bike.entity.Bike;
import com.mindtree.bike.entity.Brand;
import com.mindtree.bike.entity.Dealer;
import com.mindtree.bike.service.BikeService;
import com.mindtree.bike.service.BrandService;
import com.mindtree.bike.service.DealerService;

@Controller
public class BikeController 
{
	@Autowired
	BrandService brandservice;
	@Autowired
	DealerService dealerservice;
	@Autowired
	BikeService bikeservice;
	@RequestMapping("/")
	public String indexpage()
	{
		return "index";
	}
	@RequestMapping("/assignbrand")
	public String assignBrand(Model model)
	{
		List<Brand>brands=brandservice.getBrand();
		model.addAttribute("brand", brands);
		List<Dealer>dealers=dealerservice.getDealer();
		model.addAttribute("dealer", dealers);
		
		return "assignbrand";
	}
	@RequestMapping("/assigndealer")
	public String assignDealer(@RequestParam int brandId,@RequestParam int dealerId)
	{
		dealerservice.assignDealer(brandId,dealerId);
		
		return "index";
		
	}
	@RequestMapping("/addbrand")
	public String addBrand(Model model)
	{
		List<Brand>brands=brandservice.getBrand();
		model.addAttribute("brand", brands);
		return "addbrand";
	}
	@RequestMapping("/addbike")
	public String addBike(@RequestParam  int brandId,@RequestParam String bikeName,@RequestParam float bikePrice)
	{
		bikeservice.addBike(brandId,bikeName,bikePrice);
		return "index";
	}
	@RequestMapping("/getBike")
	public String getBike()
	{
		return "bike";
	}
	@RequestMapping("/getBikes")
	public String getBikeByDealerName(@RequestParam String dealerName,Model model)
	{
		List<Bike>bikes=dealerservice.getBikeByDealerName(dealerName);
		model.addAttribute("bike", bikes);
		return "displaybike";
		
	}
	@RequestMapping("/getinvest")
	public String getInvest()
	{
		return "invest";
		
	}

	@RequestMapping("/totalinvest")
	public String totalInvest(@RequestParam int brandId,Model model)
	{
		Float cost=brandservice.getTotalInvest(brandId);
		Brand brand=brandservice.getAllBrand(brandId);
		model.addAttribute("brand", brand);
		model.addAttribute("costs",cost);
		
		return "cost";
		
	}
	  @ExceptionHandler(value=RuntimeException.class)
	   public String RuntimeException()
	   {
		   return "error";
	   }
	

}
