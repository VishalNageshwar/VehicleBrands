package com.mindtree.bike.service;

import java.util.List;

import com.mindtree.bike.entity.Bike;
import com.mindtree.bike.entity.Dealer;

public interface DealerService 
{

	List<Dealer> getDealer();

	void assignDealer(int brandId, int dealerId);

	List<Bike> getBikeByDealerName(String dealerName);

}
