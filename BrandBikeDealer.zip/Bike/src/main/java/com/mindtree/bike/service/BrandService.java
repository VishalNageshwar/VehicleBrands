package com.mindtree.bike.service;

import java.util.List;

import com.mindtree.bike.entity.Brand;

public interface BrandService {

	List<Brand> getBrand();

	Float getTotalInvest(int brandId);

	Brand getAllBrand(int brandId);

}
